const init = () => {
  const intrebari = document.querySelectorAll(".intrebare");
  intrebari.forEach((item) => {
    item.addEventListener("click", () => {
      const id = item.querySelector("p").textContent.split(":")[1].trim();
      const raspuns = prompt("Modifica intrebarea: ");
      if (raspuns) {
        item.querySelectorAll("p")[1].textContent = "Intrebare: " + raspuns;
        for (let i = 0; i < data.length; i++) {
          if (data[i].id == id) {
            data[i].intrebare = raspuns;
            break;
          }
        }
      }
    });
    item.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      const id = item.querySelector("p").textContent.split(":")[1].trim();
      const raspuns = prompt("Modifica raspunsul: ");
      if (raspuns) {
        item.querySelectorAll("p")[2].textContent = "Raspuns: " + raspuns;
        for (let i = 0; i < data.length; i++) {
          if (data[i].id == id) {
            data[i].raspuns = raspuns;
            break;
          }
        }
      }
    });
  });
  document.addEventListener("keydown", (e) => {
    if (e.keyCode != 46) return;
    const id = prompt(
      "Introduceți id-ul întrebării pe care vreți să o ștergeți: "
    );
    intrebari.forEach((item) => {
      if (item.querySelector("p").textContent.split(":")[1].trim() == id) {
        item.remove();
        return;
      }
      for (let i = 0; i < data.length; i++) {
        if (data[i].id == id) {
          data.splice(i, 1);
          break;
        }
      }
    });
  });
  document.querySelector(".modificaIntrebare").addEventListener("submit", () => {
    document.querySelector("#dataInput").value = JSON.stringify(data);
  });
};

window.onload = init;
