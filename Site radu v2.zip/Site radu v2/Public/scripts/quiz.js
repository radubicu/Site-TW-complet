console.log(data);
function verificaRaspunsuri(){
    const raspunsuri = document.querySelectorAll("input");
    let index = 0,  raspunsuriCorecte = 0;
    raspunsuri.forEach(item => {
        if(item.value.toLowerCase().trim() == data[index].raspuns.toLowerCase()){
            item.className = "raspunsCorect";
            raspunsuriCorecte++;
        }
        else 
            item.className = "raspunsGresit";
        index++;
    });
    if(document.querySelector(".rezultat"))
        document.querySelector(".rezultat").remove();
    if(document.querySelector("img"))
        document.querySelector("img").remove();

    const rezultat = document.createElement("p");
    rezultat.className = "rezultat";
    rezultat.textContent = `Ai răspuns corect la ${raspunsuriCorecte} întrebări din ${index}. `;
    const img = document.createElement("img");
    img.setAttribute("src", "images/sad.jpg");
    img.setAttribute("height", "220");
    if(raspunsuriCorecte == index){
        rezultat.textContent = `Ai răspuns corect la toate cele ${index} întrebări. Felicitări!`;
        img.setAttribute("src", "images/wink.jpg");
    }
    document.querySelector(".continut-quiz").appendChild(rezultat);
    document.querySelector(".continut-quiz").appendChild(img);
}
const init = () => {
    listaIntrebari = document.querySelector("#listaIntrebari");
    let index = 1;
    data.forEach(item => {
        const li = document.createElement("li")
        const intrebare = document.createElement("p");
        intrebare.innerHTML = "<strong> Intrebarea " + index++ + "</strong>: " + item.intrebare;
        const inputRaspuns = document.createElement("input")
        inputRaspuns.type = "text";
        li.appendChild(intrebare);
        li.appendChild(inputRaspuns);
        listaIntrebari.appendChild(li);
    });

};

window.onload = init;