const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();
app.listen(5000);

var data = [];

fs.readFile("quiz.json", "utf-8", (err, jsonString) => {
  if (err) console.log("Error occurred");
  else {
    try {
      let old_data = JSON.parse(jsonString);
      Object.values(old_data).forEach((element) => {
        data.push(element);
      });
    } catch (err) {
      console.log("Error parsing JSON", err);
    }
  }
});

app.use(express.static(__dirname + "/public"));

app.use(bodyParser.urlencoded({extended:false}));

app.set('view engine', 'ejs');

app.get("/acasa", (req, res) => {
  res.sendFile(path.join(__dirname, "./pages/acasa.html"));
});

app.get("/", (req, res) => {
  res.redirect("/acasa");
});

app.get("/cariera", (req, res) => {
  res.sendFile(path.join(__dirname, "./pages/cariera.html"));
});

app.get("/quiz", (req, res) => {
  res.render(path.join(__dirname, "./pages/quiz"), {data});
});
app.get("/quiz_manager", (req, res) => {
  res.render(path.join(__dirname, "./pages/quiz_manager"), {data});
});
app.post("/adaugaIntrebare", (req, res) => {
  const {intrebare, raspuns} = req.body;
  let id = 0;
  if(data.length)
    id = data[data.length-1].id + 1;
  data[data.length] = {
    id, 
    intrebare,
    raspuns
  };
  fs.writeFileSync("quiz.json", JSON.stringify(data, null, 2));
  res.redirect("/quiz_manager");
});

app.post("/modificaIntrebare", (req, res) => {
  data = JSON.parse(req.body.data);
  fs.writeFileSync("quiz.json", JSON.stringify(data, null, 2));
  res.redirect("/quiz_manager");
});